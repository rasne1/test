//https://api.github.com/users
$().ready(function () {
  $(".load-git-users").on("click", function () {
    var jsonProm = fetch("https://api.github.com/users");
    console.log(jsonProm);

    jsonProm
      .then(function (jsonResponse) {
        return jsonResponse.json();
      })
      .then(function (body) {
        for (var i = 0; i < body.length; i++) {
          var posts = body[i];
          var bodyPosts = posts.body;
          var li = $("<li>").text(bodyPosts);
          $(".posts").append(li);
        }
      });
  });
});
