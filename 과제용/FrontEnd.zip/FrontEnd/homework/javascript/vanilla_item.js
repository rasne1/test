window.onload = function () {
  var itemList = document.querySelector(".item-list");
  var add = document.querySelector(".item-add");
  var itemDelete = document.querySelector(".all-item-delete");
  var totalItem = document.querySelector(".total-count");

  add.addEventListener("click", function () {
    var count = document.querySelectorAll(".item-list li");
    if (count.length < 10) {
      var addList = document.createElement("li");
      addList.innerText = "아이템 목록 " + (count.length + 1);
      itemList.appendChild(addList);
    } else {
      alert("더 이상 추가할 수 없습니다.");
    }
  });

  itemDelete.addEventListener("click", function () {
    var count = document.querySelectorAll(".item-list li");
    if (count.length > 0) {
      //var deleteList = document.querySelector(".item-list li");
      //deleteList.replaceChildren();
      for (var i = 0; i <= count.length; i++) {
        count[i].remove();
      }
    } else {
      alert("이미 모든 아이템이 제거되었습니다.");
    }
  });
  add.addEventListener("click", function () {
    var count = document.querySelectorAll(".item-list li");
    totalItem.innerText =
      "총 " + count.length + " 개의 아이템이 등록 되었습니다.";
  });
  itemDelete.addEventListener("click", function () {
    var count = document.querySelectorAll(".item-list li");
    totalItem.innerText =
      "총 " + count.length + " 개의 아이템이 등록 되었습니다.";
  });
};
