$().ready(function () {
  var add = $(".item-add");
  var allDelete = $(".all-item-delete");
  var totalCount = $(".total-count");

  add.on("click", function () {
    var count = $(".item-list li").length + 1;
    var newLi = $("<li>");
    if (count > 10) {
      alert("더 이상 추가할 수 없습니다.");
    } else {
      newLi.text("아이템 목록 " + count);
      $(".item-list").append(newLi);
    }
  });

  allDelete.on("click", function () {
    var count = $(".item-list li").length;
    if (count > 0) {
      $(".item-list li").remove();
    } else {
      alert("이미 모든 아이템이 제거되었습니다.");
    }
  });

  $(".item-add, .all-item-delete").on("click", function () {
    var addCount = $(".item-list li").length;
    totalCount.text("총 " + addCount + " 개의 아이템이 등록되었습니다");
  });
});
