$(document).ready(function () {

    $(".add-button").on("click", function () {

        var item_count = 0;

        $(".item").each(function () {
            item_count++;
        });

        if (item_count >= 10) {
            alert("더 이상 추가할 수 없음");
            return;
        }
        item_count++;

        var addItem = $("<div>");
        addItem.addClass("item");           // children.length를 했는데 x
        addItem.text("아이템 목록 " + item_count);

        $(".list-button").append(addItem);

        result();
    });

    $(".remove-button").on("click", function () {

        var item_count;

        $(".list-button").empty();

        result();

        if (item_count == 0) {
            alert("이미 모든 아이템이 제거되었습니다");
            return;
        }
    });

    function result() {

        var item_count = $(".item").length;

        $(".items").text(
            "총 " + item_count + "개의 아이템이 등록되었습니다."
        );
    }

});

// window.onload = function () {

//     document.querySelector(".add-button").addEventListener("click", function () {

//         var item_count = 0;

//         var items = document.querySelectorAll(".item");
//         for (var i = 0; i < items.length; i++) {
//             item_count++;
//         }

//         if (item_count >= 10) {
//             alert("더 이상 추가할 수 없음");
//             return;
//         }
//         item_count++;

//         var addItem = document.createElement("div");
//         addItem.className = "item";
//         addItem.innerText = "아이템 목록 " + item_count;

//         document.querySelector(".list-button").appendChild(addItem);

//         result();
//     });

//     document.querySelector(".remove-button").addEventListener("click", function () {

//         var item_count = document.querySelectorAll(".item").length;

//         if (item_count == 0) {
//             alert("이미 모든 아이템이 제거되었습니다");
//             return;
//         }

//         document.querySelector(".list-button").innerText = "";

//         result();
//     });

//     function result() {

//         var item_count = document.querySelectorAll(".item").length;

//         document.querySelector(".items").innerText =
//             "총 " + item_count + "개의 아이템이 등록되었습니다.";
//     }

// };