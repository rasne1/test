// 1. 버튼
// - 클릭하면 3번 목록 가장 아래에 아이템이 추가되어야 한다.
// - 아이템의 내용은 “아이템 목록 아이템 개수 + 형태로 추가되어야 한다.
// - 추가할 때 마다 4번 박스는 “총 n개의 아이템이 등록되었습니다.” 로 갱신되어야 한다.
// - 10개 이상의 아이템은 등록할 수 없다.
// - 10개 이상의 아이템을 등록하려 하면 “더 이상 추가할 수 없습니다” 경고창이 나타난다.

// 2. 버튼
// - 클릭하면 3번 목록의 모든 아이템들이 제거된다.
// - 클릭하면 4번 항목은 “총 0개의 아이템이 등록되었습니다.” 로 갱신되어야 한다.
// - 3번 항목에 등록된 아이템이 없는 상태에서 클릭하면 “이미 모든 아이템이 제거되었습니다” 경고창이 나타난다.

// 3. 리스트
// - 1번 버튼을 통해 아이템이 등록된다.

// 3-1.
// - 아이템에 마우스가 올라가면 배경색과 글자색상이 변경되어야 한다.

// 4.
// - 1번 버튼과 2번 버튼의 영향을 받는 박스.
// - 다른 기능은 없다.

// jQuery
// $().ready(function () {
//   // 몇번째 박스
//   var n = 1;
//   $(".add").on("click", function () {
//     if (n < 10) {
//       var newBox = $("<div>");
//       newBox.text("아이템 목록 " + n);
//       $(this).parent().next().append(newBox);
//       newBox.addClass("hover");
//       $(".totalBox").text("총" + n + "개의 아이템이 등록되었습니다.");
//       n++;
//     } else {
//       alert("더이상 추가할 수 없습니다.");
//     }
//   });

//   $(".removeAll").on("click", function () {
//     if ($(this).parent().next().children().length != 0) {
//       $(this).parent().next().children().remove();

//       $(".totalBox").text("총" + 0 + "개의 아이템이 등록되었습니다.");
//       n = 1;
//     } else {
//       alert("이미 모든 아이템이 제거되었습니다.");
//     }
//   });

//   $(".box").children().on("hover");
// });

// vanilla script
window.onload = function () {
  var add = document.querySelector(".add");
  var box = document.querySelector(".box");
  var totalBox = document.querySelector(".totalBox");
  var removeAll = document.querySelector(".removeAll");
  var n = 1;

  add.addEventListener("click", function () {
    if (n < 10) {
      // console.log("!");
      var newBox = document.createElement("div");
      newBox.innerText = "아이템 목록 " + n;
      newBox.className = "hover";
      box.appendChild(newBox);
      totalBox.innerText = "총 " + n + "개의 아이템이 등록되었습니다.";
      n++;
    } else {
      alert("더이상 추가할 수 없습니다.");
    }
  });

  removeAll.addEventListener("click", function () {
    if (this.parentElement.nextElementSibling.children.length !== 0) {
      box.innerText = "";
      totalBox.innerText = "총 0개의 아이템이 등록되었습니다.";

      n = 1;
    } else {
      alert("이미 모든 아이템이 제거되었습니다.");
    }
  });
};
