$().ready(function () {
    var itemNum = 0;
    var item = [];

    $(".header__add").on("click", function () {
        var addDiv = $("<div>");
        var addItem = $("<div>");
        var deleteBtn = $("<div>");

        deleteBtn.addClass("delete__button")
        deleteBtn.text("X");

        if (item.length < 9) {
            item.push(itemNum);
            addItem.text("아이템 목록 " + ++itemNum);
            addDiv.append(addItem);
            addDiv.append(deleteBtn);
            $(".content").append(addDiv);
        } else {
            alert("더 이상 추가할 수 없습니다.")
        }

        $(".footer").text("총 " + item.length + "개의 아이템이 등록되었습니다");
    });

    // ToDo 더블 클릭시 내용 수정
    $(".content").on("dblclick", "div > div:first-child", function () {
        $(this).parent().remove();
    })

    $(".header__removeall").on("click", function () {
        if (!item.length) {
            alert("이미 모든 아이템이 제거되었습니다.");
            return;
        }
        $(".content > div").remove();
        itemNum = 0;
        item = [];

        $(".footer").text("총 " + item.length + "개의 아이템이 등록되었습니다");
        
    });
    
    $(".content").on("click", ".delete__button", function () {
        item.length--;
        $(this).parent().remove();
        
        $(".footer").text("총 " + item.length + "개의 아이템이 등록되었습니다");
    })
    
    $(".footer").text("총 " + item.length + "개의 아이템이 등록되었습니다");
})
