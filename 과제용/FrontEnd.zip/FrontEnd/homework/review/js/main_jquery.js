$().ready(function () {
  $(".item-add").on("click", function () {
    var list = $(".item-list");
    var listcount = list.children().length;
    if (listcount < 10) {
      var newLi = $("<li>");
      newLi.text("아이템 목록 " + (listcount + 1));
      list.append(newLi);
      $(".E-box").text(
        "총 " + (listcount + 1) + "개의 아이템이 등록되었습니다.",
      );
    } else {
      alert("더 이상 추가 할 수 없습니다");
    }
  });
  $(".remove-all-item").on("click", function () {
    var list = $(".item-list");
    var listcount = list.children("li").length;
    if (listcount === 0) {
      alert("이미 모든 아이템이 제거되었습니다.");
    }
    list.children().remove();
  });
});
