window.onload = function () {
  var addbt = document.querySelector(".item-add");
  var debt = document.querySelector(".remove-all-item");
  var list = document.querySelector(".item-list");
  var total = document.querySelector(".E-box");

  addbt.addEventListener("click", function () {
    var totalcount = list.children.length;

    if (totalcount < 10) {
      var newli = document.createElement("li");
      newli.innerText = "아이템 목록 " + (totalcount + 1);
      list.appendChild(newli);
      total.innerText =
        "총 " + (totalcount + 1) + "개의 아이템이 등록되었습니다.";
    } else {
      alert("더 이상 등록 할 수 없습니다");
    }
  });
  debt.addEventListener("click", function () {
    var deitem = list.querySelectorAll("li");
    var totalcount = list.children.length;

    if (totalcount === 0) {
      alert("이미 모든 아이템이 제거되었습니다.");
    }

    for (var i = 0; i < deitem.length; i++) {
      deitem[i].remove();
    }

    total.innerText = "등록된 아이템이 없습니다.";
  });
};
