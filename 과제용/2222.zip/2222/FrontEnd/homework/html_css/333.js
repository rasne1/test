window.onload = function () {
  var but = document.querySelector(".a");
  var list = document.querySelector(".list");
  var input = this.document.querySelector("input");

  but = addEventListener("click", function () {
    var text = input.value;

    var li = document.createElement("li");
    li.textContent = text;
    list.appendChild(li);
  });
};
