window.onload = function () {
  var c = document.querySelector(".count");
  var add = document.querySelector(".a");
  var d = document.querySelector(".b");

  add.addEventListener("click", function () {
    var num = parseInt(c.innerText);
    c.innerText = num + 1;
  });
  d.addEventListener("click", function () {
    var num = parseInt(c.innerText);
    c.innerText = num - 1;
  });
};
