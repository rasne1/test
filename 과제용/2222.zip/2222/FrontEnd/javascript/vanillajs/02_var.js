window.onload = function () {
  var number = 10;
  console.log("변수의값은", number, "변수의 타입은", typeof number);

  number = "아아아아아아아아";
  console.log("변수의값은", number, "변수의 타입은", typeof number);

  var x;
  console.log("변수의값은", x, "변수의 타입은", typeof x);

  var x2 = null;
  console.log("변수의값은", x2, "변수의 타입은", typeof x2);

  var x2 = 213.1513135132;
  console.log("변수의값은", x2, "변수의 타입은", typeof x2);

  x3 = "asdasdasd";
  console.log("변수의값은", x3, "변수의 타입은", typeof x3);
};
