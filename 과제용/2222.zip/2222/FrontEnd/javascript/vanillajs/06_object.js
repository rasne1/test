String.prototype.replaceAll = function (findText, replaceText) {
  console.log(findText, " 를 찾아서 ", replaceText, "로 바꾸려고 하는군요");

  return this;
};

var text = "aaa";
text = text.replaceAll("a", "z");
console.log(text);

//String에 contains 라는 기능을 추가한다.
String.prototype.contains = function (findText) {
  console.log(findText);
  console.log(this);
  return this.indexOf(findText) >= 0;
};

// tempObject에 print 라는 기능을 추가.
Object.prototype.print = function () {
  console.log("객체의 내용", this);
};
var tempObject = {};
tempObject.print();
console.dir(tempObject);

var text = "sadasdasd";
text.print();

window.onload = function () {
  var text = "abcdefg abcdefg";
  //String의 기능이 뭐가있나? ==> String
  console.dir(String);
  var contain = text.contains("a");

  console.log(contain);

  // 객체 구조(상속)

  //console.dir(String);

  var list = document.querySelector(".list");
  var listItem = [
    { tagName: "li", text: "first", class: "list-item" },
    { tagName: "li", text: "second", class: "list-item" },
    { tagName: "li", text: "third", class: "list-item" },
  ];

  listItem.print();

  for (var i = 0; i < listItem.length; i++) {
    var item = listItem[i];
    item.print();
    var eachItem = document.createElement(item.tagName);
    eachItem.className = item.class;
    eachItem.innerText = item.text;

    list.appendChild(eachItem);
  }

  function calc(param) {
    return (param.n1 || 0) + (param.n2 || 0) + (param.n3 || 0);
  }

  var result = calc({ n1: 10, n3: 55 });
  console.log(result);

  function getObject() {
    return {
      price: 12312313,
      name: "dkdmcm",
      model: "20002",
      fan: 8,
      chain: ["GS", "CJ", "HANJIN"],
      address: {
        city: "seoul",
        state: "bonchun",
      },
    };
  }

  var obj = getObject();
  console.log(obj.chain);

  var headphone = {
    "serial-number": "513531-513513",
    modelName: "XM-5",
    manufacture: "Sony",
    type: "over-ear",
    power: false,
    powerOn: function () {
      console.log(this.modelName, "이 켜집니다.");
      this.power = true;
    },
    powerOff: function () {
      console.log(this.modelName, "이 꺼집니다.");
      this.power = false;
    },
  };
  console.log(headphone, typeof headphone);

  console.log(headphone.modelName);
  console.log(headphone["modelName"]);

  //console.log(headphone."serial-number"); erorr
  console.log(headphone["serial-number"]);
  headphone.powerOn();
  console.log(headphone.powerOn);
};
