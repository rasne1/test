$().ready(function () {
  var listItems = $(".contact");
  listItems.on("click", function () {
    // console.log(
    //   "package-deal-comment 내용",
    //   $(this)
    //     .prev()
    //     .find(".package-deal-comment")
    //     .text());
    //     }),
    // );
    $(this)
      .prev()
      .find(".package-deal-comment")
      .each(function () {
        console.log($(this).text());
      });
  });

  $(".package-green-button").on("click", function () {
    var price = $(this).closest(".package").data("price");

    var newP = $("<p>");

    newP.text("From $" + price);

    //새롭게 만든 p태그에게 inline style 을 부여한다.
    //newP.css({ color: "#fff" });-권장되지않는 방법
    //새롭게 만든 p 태그에게 ".withe-color" 에게 클래스를 부여한다.
    newP.addClass("white-color"); // 클래스 부여하는 방법.

    $(this).after(newP);

    //브라우저 메모리에서 해당 DOM을 완전제거.

    // .detach() /브라우저 메모리는 삭제하지 않고 화면에서 제거.

    $(this).remove();
  });
});
