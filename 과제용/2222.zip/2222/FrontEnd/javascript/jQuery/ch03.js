$().ready(function () {
  // #destinations > li 는 에 있는 li를 찾아라
  var listItem = $("#destinations").children("li");
  console.log(listItem);
  // listItems[i].addEventListener("click", function (event) {}); 대체
  listItem.on("click", function () {
    // console.log("클릭한 태그의 내용", event.target.innerText);
    console.log("클릭한 태그의 내용", $(this).text());

    //   "클릭한 태그의 이전 태그 내용",
    //         event.target.previousElementSibling.innerText,
    //       );
    console.log("클릭한 태그의 이전 태그 내용", $(this).prev().text());

    //         "클릭한 태그 이후의 태그의 내용",
    //         event.target.nextElementSibling.innerText,
    //       );

    console.log("클릭한 태그 이후의 태그의 내용", $(this).next().text());

    //         "클릭한 태그의 부모태그 내용",
    //         event.target.parentElement.innerText,
    //       );

    console.log("클릭한 태그의 부모태그 내용", $(this).parent().text());
  });
});

// window.onload = function () {
//   var listItems = document.querySelectorAll("#destinations > li");

//   for (var i = 0; i < listItems.length; i++) {
//     listItems[i].addEventListener("click", function (event) {
//       console.dir(event.target);
//       console.log("클릭한 태그의 내용", event.target.innerText);
//       console.log(
//         "클릭한 태그의 이전 태그 내용",
//         event.target.previousElementSibling.innerText,
//       );
//       console.log(
//         "클릭한 태그 이후의 태그의 내용",
//         event.target.nextElementSibling.innerText,
//       );
//       console.log(
//         "클릭한 태그의 부모태그 내용",
//         event.target.parentElement.innerText,
//       );
//     });
//   }
// };
